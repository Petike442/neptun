import fs from 'fs';
import path from 'path';
import zlib from 'zlib';

function createCRC32Table() {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    }
    table[i] = c;
  }
  return table;
}

const crcTable = createCRC32Table();

function crc32(buf) {
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    crc = (crc >>> 8) ^ crcTable[(crc ^ buf[i]) & 0xff];
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function writeChunk(type, data) {
  const len = data.length;
  const buf = Buffer.alloc(12 + len);
  buf.writeUInt32BE(len, 0);
  buf.write(type, 4, 4, 'ascii');
  data.copy(buf, 8);
  const typeAndData = buf.subarray(4, 8 + len);
  buf.writeUInt32BE(crc32(typeAndData), 8 + len);
  return buf;
}

function generatePNG(width, height, isMaskable = false) {
  // Generate RGBA buffer
  // Format: for each scanline: filter byte (0) + width * 4 bytes
  const rowSize = 1 + width * 4;
  const rawData = Buffer.alloc(rowSize * height);

  // Background: rich dark emerald slate gradient
  // Center logo: emerald/teal graduation cap & calendar
  const cx = width / 2;
  const cy = height / 2;
  const radius = width * 0.44;

  for (let y = 0; y < height; y++) {
    const rowOffset = y * rowSize;
    rawData[rowOffset] = 0; // Filter type 0 (None)

    for (let x = 0; x < width; x++) {
      const pxOffset = rowOffset + 1 + x * 4;
      const dx = x - cx;
      const dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);

      // Base background gradient: dark slate (#020617 to #0f172a)
      let r = 2 + Math.floor((x / width) * 10);
      let g = 6 + Math.floor((y / height) * 20);
      let b = 23 + Math.floor(((x + y) / (width * 2)) * 25);
      let a = 255;

      // Inner rounded badge / squircle
      const cardMargin = isMaskable ? width * 0.18 : width * 0.08;
      const insideCard = (x >= cardMargin && x <= width - cardMargin && y >= cardMargin && y <= height - cardMargin);

      if (insideCard) {
        // Emerald vibrant glow in center
        const glow = Math.max(0, 1 - (dist / (width * 0.45)));
        r = Math.min(255, Math.floor(5 + glow * 16));
        g = Math.min(255, Math.floor(30 + glow * 155));
        b = Math.min(255, Math.floor(45 + glow * 115));

        // Draw calendar / graduation cap simple icon geometry
        // Central box: calendar icon
        const calL = width * 0.28;
        const calR = width * 0.72;
        const calT = height * 0.30;
        const calB = height * 0.74;

        if (x >= calL && x <= calR && y >= calT && y <= calB) {
          // Border or fill
          const isBorder = (x - calL < width * 0.03 || calR - x < width * 0.03 || y - calT < height * 0.03 || calB - y < height * 0.03);
          const isHeader = (y >= calT && y <= calT + height * 0.12);

          if (isHeader) {
            // Bright emerald header
            r = 16;
            g = 185;
            b = 129;
          } else if (isBorder) {
            r = 52;
            g = 211;
            b = 153;
          } else {
            // Inside calendar: grid dots / cells
            const gridX = (x - calL) / (calR - calL);
            const gridY = (y - calT) / (calB - calT);
            const inCell = ((Math.floor(gridX * 4) + Math.floor(gridY * 4)) % 2 === 0);
            if (inCell) {
              r = 15;
              g = 45;
              b = 40;
            } else {
              r = 6;
              g = 78;
              b = 59;
            }
          }
        }
      }

      rawData[pxOffset] = r;
      rawData[pxOffset + 1] = g;
      rawData[pxOffset + 2] = b;
      rawData[pxOffset + 3] = a;
    }
  }

  // Compress IDAT
  const compressed = zlib.deflateSync(rawData);

  // PNG Signature
  const signature = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

  // IHDR
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData[8] = 8; // Bit depth: 8
  ihdrData[9] = 6; // Color type: 6 (RGBA)
  ihdrData[10] = 0; // Compression: 0
  ihdrData[11] = 0; // Filter: 0
  ihdrData[12] = 0; // Interlace: 0
  const ihdrChunk = writeChunk('IHDR', ihdrData);

  // IDAT
  const idatChunk = writeChunk('IDAT', compressed);

  // IEND
  const iendChunk = writeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// Generate apple-touch-icon.png (180x180)
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), generatePNG(180, 180, false));
console.log('Generated public/apple-touch-icon.png');

// Generate pwa-192x192.png
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), generatePNG(192, 192, false));
console.log('Generated public/pwa-192x192.png');

// Generate pwa-512x512.png
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), generatePNG(512, 512, false));
console.log('Generated public/pwa-512x512.png');

// Generate pwa-maskable-512x512.png
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), generatePNG(512, 512, true));
console.log('Generated public/pwa-maskable-512x512.png');
